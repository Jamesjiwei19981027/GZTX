/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Task,
  Project,
  Activity,
  UserProfile,
  AppSettings,
  ViewMode,
  Status,
} from './types';
import {
  loadTasks,
  saveTasks,
  loadProjects,
  saveProjects,
  loadSettings,
  saveSettings,
  resetDemoData,
  INITIAL_USER,
  INITIAL_ACTIVITIES,
} from './data/mockData';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/views/DashboardView';
import { MyTasksView } from './components/views/MyTasksView';
import { KanbanView } from './components/views/KanbanView';
import { CalendarView } from './components/views/CalendarView';
import { SettingsView } from './components/views/SettingsView';
import { ReportsView } from './components/views/ReportsView';
import { TeamView } from './components/views/TeamView';
import { InboxView } from './components/views/InboxView';
import { MessagesView } from './components/views/MessagesView';
import { PeopleAxisView } from './components/views/PeopleAxisView';
import { NewTaskModal } from './components/modals/NewTaskModal';
import { TaskDetailDrawer } from './components/modals/TaskDetailDrawer';
import { NotificationsModal } from './components/modals/NotificationsModal';

const ALL_PROJECT_ITEM: Project = {
  id: 'all',
  name: '全盘研发概览 (All Projects Overview)',
  description: '跨区域、跨产线企业协同整体路线图',
  color: '#4f378b',
  active: true,
};

export default function App() {
  // State initialization from local storage or defaults
  const [tasks, setTasks] = useState<Task[]>(() => loadTasks());
  const [projects, setProjects] = useState<Project[]>(() => loadProjects());
  const [currentProject, setCurrentProject] = useState<Project>(ALL_PROJECT_ITEM);
  const [activities, setActivities] = useState<Activity[]>(INITIAL_ACTIVITIES);
  const [user, setUser] = useState<UserProfile>(INITIAL_USER);
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());

  // Navigation & UI state
  const [activeView, setActiveView] = useState<ViewMode>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  // Modal state
  const [isNewTaskModalOpen, setIsNewTaskModalOpen] = useState<boolean>(false);
  const [newTaskDefaultStatus, setNewTaskDefaultStatus] = useState<Status | undefined>(undefined);
  const [newTaskDefaultDate, setNewTaskDefaultDate] = useState<string | undefined>(undefined);
  const [newTaskDefaultTitle, setNewTaskDefaultTitle] = useState<string | undefined>(undefined);
  const [newTaskDefaultDesc, setNewTaskDefaultDesc] = useState<string | undefined>(undefined);
  const [isNotificationsModalOpen, setIsNotificationsModalOpen] = useState<boolean>(false);

  // Global Alt+N shortcut for quick task creation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && (e.key === 'n' || e.key === 'N' || e.code === 'KeyN')) {
        e.preventDefault();
        setNewTaskDefaultTitle('');
        setNewTaskDefaultDesc('');
        setNewTaskDefaultStatus('To Do');
        setNewTaskDefaultDate(undefined);
        setIsNewTaskModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Persist tasks when changed
  useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  // Persist projects when changed
  useEffect(() => {
    saveProjects(projects);
  }, [projects]);

  // Persist settings & apply theme when changed
  useEffect(() => {
    saveSettings(settings);
    const root = document.documentElement;
    if (settings.themeMode === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings]);

  // All available projects for navbar dropdown
  const displayProjects = useMemo(() => {
    return [ALL_PROJECT_ITEM, ...projects];
  }, [projects]);

  // Filter tasks based on current project selection and search query
  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      const matchesProject =
        currentProject.id === 'all' || t.projectId === currentProject.id || !t.projectId;
      const query = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !query ||
        t.title.toLowerCase().includes(query) ||
        (t.description && t.description.toLowerCase().includes(query)) ||
        (t.tag && t.tag.toLowerCase().includes(query));
      return matchesProject && matchesSearch;
    });
  }, [tasks, currentProject, searchQuery]);

  // Helper to add activity log
  const addActivity = (
    type: 'completed' | 'updated' | 'collaborator' | 'created',
    titleText: string,
    targetText: string,
    timestamp: string = '刚刚 (Just now)'
  ) => {
    const iconMap = {
      completed: 'check',
      updated: 'edit',
      collaborator: 'group',
      created: 'add_circle',
    };
    const colorMap = {
      completed: 'bg-secondary-container text-on-secondary-container',
      updated: 'bg-primary-fixed text-on-primary-fixed',
      collaborator: 'bg-tertiary-fixed text-on-tertiary-fixed',
      created: 'bg-primary text-on-primary',
    };
    const newActivity: Activity = {
      id: `act_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      type,
      titleText,
      targetText,
      timestamp,
      icon: iconMap[type],
      colorClass: colorMap[type],
    };
    setActivities((prev) => [newActivity, ...prev.slice(0, 19)]);
  };

  // Task Action Handlers
  const handleCreateTask = (taskData: Omit<Task, 'id'>) => {
    const targetProjectId =
      currentProject.id === 'all' ? (projects[0]?.id || 'p1') : currentProject.id;
    const newTask: Task = {
      ...taskData,
      id: `t_${Date.now()}`,
      projectId: taskData.projectId || targetProjectId,
    };
    setTasks((prev) => [newTask, ...prev]);
    addActivity('created', '新任务创建 (New task created):', newTask.title);
    setIsNewTaskModalOpen(false);
  };

  const handleUpdateTask = (updatedTask: Task) => {
    setTasks((prev) => prev.map((t) => (t.id === updatedTask.id ? updatedTask : t)));
    addActivity('updated', '任务详情已修整 (Task updated):', updatedTask.title);
    setSelectedTask(updatedTask);
  };

  const handleDeleteTask = (taskId: string) => {
    const taskToDelete = tasks.find((t) => t.id === taskId);
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
    if (taskToDelete) {
      addActivity('updated', '任务已归档删除 (Task deleted):', taskToDelete.title);
    }
    setSelectedTask(null);
  };

  const handleToggleTaskCompletion = (taskId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId) {
          const isDone = t.status === 'Done';
          const nextStatus: Status = isDone ? 'To Do' : 'Done';
          const updatedTask = {
            ...t,
            status: nextStatus,
            completedAt: !isDone
              ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              : undefined,
            progress: !isDone ? 100 : 0,
          };
          if (!isDone) {
            addActivity('completed', '任务已达成 (Task completed):', t.title);
          }
          return updatedTask;
        }
        return t;
      })
    );
  };

  const handleUpdateTaskStatus = (taskId: string, newStatus: Status) => {
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === taskId && t.status !== newStatus) {
          const isDone = newStatus === 'Done';
          if (isDone) {
            addActivity('completed', '状态流转至完成 (Status moved to Done):', t.title);
          } else {
            addActivity('updated', `任务流转 (${newStatus}):`, t.title);
          }
          return {
            ...t,
            status: newStatus,
            completedAt: isDone ? '刚刚 (Just now)' : undefined,
            progress:
              newStatus === 'In Progress' && (!t.progress || t.progress === 0) ? 50 : isDone ? 100 : 0,
          };
        }
        return t;
      })
    );
  };

  // Modal trigger helpers
  const handleOpenNewTask = () => {
    setNewTaskDefaultTitle('');
    setNewTaskDefaultDesc('');
    setNewTaskDefaultStatus('To Do');
    setNewTaskDefaultDate(undefined);
    setIsNewTaskModalOpen(true);
  };

  const handleOpenNewTaskWithStatus = (status: Status) => {
    setNewTaskDefaultTitle('');
    setNewTaskDefaultDesc('');
    setNewTaskDefaultStatus(status);
    setNewTaskDefaultDate(undefined);
    setIsNewTaskModalOpen(true);
  };

  const handleOpenNewTaskWithDate = (dateStr: string) => {
    setNewTaskDefaultTitle('');
    setNewTaskDefaultDesc('');
    setNewTaskDefaultStatus('To Do');
    setNewTaskDefaultDate(dateStr);
    setIsNewTaskModalOpen(true);
  };

  const handleOpenNewTaskWithTitle = (title: string, desc: string) => {
    setNewTaskDefaultTitle(title);
    setNewTaskDefaultDesc(desc);
    setNewTaskDefaultStatus('To Do');
    setNewTaskDefaultDate(undefined);
    setIsNewTaskModalOpen(true);
  };

  // Settings & user updates
  const handleUpdateUser = (updated: Partial<UserProfile>) => {
    setUser((prev) => ({ ...prev, ...updated }));
  };

  const handleUpdateSettings = (updated: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...updated }));
  };

  const handleToggleLang = () => {
    setSettings((prev) => ({
      ...prev,
      language: prev.language === 'zh' ? 'en' : 'zh',
    }));
  };

  const handleResetDemo = () => {
    resetDemoData();
    const loadedTasks = loadTasks();
    const loadedProjects = loadProjects();
    const loadedSettings = loadSettings();
    setTasks(loadedTasks);
    setProjects(loadedProjects);
    setSettings(loadedSettings);
    setCurrentProject(ALL_PROJECT_ITEM);
    setActivities(INITIAL_ACTIVITIES);
    setUser(INITIAL_USER);
  };

  return (
    <div className="min-h-screen flex flex-col bg-surface dark:bg-[#111314] text-on-surface dark:text-[#e2e2e5] font-sans transition-colors duration-200">
      {/* Fixed Top Navigation Bar */}
      <Navbar
        currentProject={currentProject}
        projects={displayProjects}
        onSelectProject={(proj) => setCurrentProject(proj)}
        user={user}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        lang={settings.language}
        onToggleLang={handleToggleLang}
        onOpenSettings={() => setActiveView('settings')}
        onResetDemo={handleResetDemo}
        onOpenNewTask={handleOpenNewTask}
        onOpenNotifications={() => setIsNotificationsModalOpen(true)}
      />

      {/* Main Workspace Layout */}
      <div className="flex flex-1 pt-16">
        {/* Fixed Left Sidebar (Desktop) & Bottom Navigation (Mobile) */}
        <Sidebar
          activeView={activeView}
          onSelectView={setActiveView}
          onOpenNewTask={handleOpenNewTask}
          lang={settings.language}
        />

        {/* Dynamic Content Area */}
        <main className="flex-1 md:pl-[280px] pb-20 md:pb-8 min-w-0 transition-all duration-200">
          <div className="max-w-7xl mx-auto">
            {activeView === 'dashboard' && (
              <DashboardView
                user={user}
                tasks={filteredTasks}
                activities={activities}
                onSelectTask={setSelectedTask}
                onOpenNewTask={handleOpenNewTask}
                onNavigateToTasks={() => setActiveView('tasks')}
                onNavigateToPeopleAxis={() => setActiveView('people-axis')}
                lang={settings.language}
              />
            )}

            {activeView === 'people-axis' && (
              <PeopleAxisView lang={settings.language} />
            )}

            {activeView === 'tasks' && (
              <MyTasksView
                tasks={filteredTasks}
                onToggleTaskCompletion={handleToggleTaskCompletion}
                onSelectTask={setSelectedTask}
                lang={settings.language}
              />
            )}

            {activeView === 'kanban' && (
              <KanbanView
                tasks={filteredTasks}
                onUpdateTaskStatus={handleUpdateTaskStatus}
                onSelectTask={setSelectedTask}
                onOpenNewTaskWithStatus={handleOpenNewTaskWithStatus}
                lang={settings.language}
              />
            )}

            {activeView === 'calendar' && (
              <CalendarView
                tasks={filteredTasks}
                onSelectTask={setSelectedTask}
                onOpenNewTaskWithDate={handleOpenNewTaskWithDate}
                lang={settings.language}
              />
            )}

            {activeView === 'reports' && (
              <ReportsView
                tasks={tasks}
                lang={settings.language}
              />
            )}

            {activeView === 'team' && (
              <TeamView
                onSelectMember={(m) => alert(settings.language === 'zh' ? `选中了团队成员: ${m.name}` : `Selected member: ${m.name}`)}
                onNavigateToMessages={() => setActiveView('messages')}
                lang={settings.language}
              />
            )}

            {activeView === 'inbox' && (
              <InboxView
                onOpenNewTaskWithTitle={handleOpenNewTaskWithTitle}
                lang={settings.language}
              />
            )}

            {activeView === 'messages' && (
              <MessagesView
                user={user}
                lang={settings.language}
              />
            )}

            {activeView === 'settings' && (
              <SettingsView
                user={user}
                onUpdateUser={handleUpdateUser}
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                onResetDemo={handleResetDemo}
                lang={settings.language}
              />
            )}
          </div>
        </main>
      </div>

      {/* New Task Creation Modal */}
      <NewTaskModal
        isOpen={isNewTaskModalOpen}
        onClose={() => setIsNewTaskModalOpen(false)}
        onCreateTask={handleCreateTask}
        currentProject={
          currentProject.id === 'all'
            ? projects[0] || { id: 'p1', name: '默认项目', description: '', color: '#0058be', active: true }
            : currentProject
        }
        defaultStatus={newTaskDefaultStatus}
        defaultDate={newTaskDefaultDate}
        defaultPriority={settings.taskDefaults.priority}
        defaultCategory={settings.taskDefaults.category}
        defaultTitle={newTaskDefaultTitle}
        defaultDescription={newTaskDefaultDesc}
        lang={settings.language}
      />

      {/* Task Details & Edit Drawer */}
      <TaskDetailDrawer
        task={selectedTask}
        onClose={() => setSelectedTask(null)}
        onUpdateTask={handleUpdateTask}
        onDeleteTask={handleDeleteTask}
        lang={settings.language}
      />

      {/* Notifications Modal */}
      <NotificationsModal
        isOpen={isNotificationsModalOpen}
        onClose={() => setIsNotificationsModalOpen(false)}
        onSelectTaskId={(id) => {
          const t = tasks.find((x) => x.id === id);
          if (t) setSelectedTask(t);
        }}
        onOpenSettings={() => setActiveView('settings')}
        lang={settings.language}
      />
    </div>
  );
}

