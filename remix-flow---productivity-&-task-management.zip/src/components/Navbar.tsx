import React, { useState } from 'react';
import { Project, UserProfile, Language } from '../types';
import { getT } from '../i18n';

interface NavbarProps {
  currentProject: Project;
  projects: Project[];
  onSelectProject: (project: Project) => void;
  user: UserProfile;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  lang: Language;
  onToggleLang: () => void;
  onOpenSettings: () => void;
  onResetDemo: () => void;
  onOpenNewTask?: () => void;
  onOpenNotifications?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentProject,
  projects,
  onSelectProject,
  user,
  searchQuery,
  onSearchChange,
  lang,
  onToggleLang,
  onOpenSettings,
  onResetDemo,
  onOpenNewTask,
  onOpenNotifications,
}) => {
  const t = getT(lang);
  const [showProjectDropdown, setShowProjectDropdown] = useState(false);
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);

  return (
    <>
      <header className="bg-surface dark:bg-[#191c1d] border-b border-surface-variant dark:border-outline-variant flex justify-between items-center w-full px-4 lg:px-6 h-16 fixed top-0 z-50 shadow-sm transition-colors duration-200">
        {/* Left Section: Brand & Workspace */}
        <div className="flex items-center gap-3 md:gap-4">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setShowProjectDropdown(!showProjectDropdown)}>
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-on-primary font-bold text-lg shadow-sm">
              F
            </div>
            <span className="text-2xl font-bold text-primary dark:text-[#adc6ff] tracking-tight">
              Flow
            </span>
          </div>

          <div className="h-6 w-[1px] bg-outline-variant dark:bg-outline mx-1 md:mx-2 hidden sm:block"></div>

          {/* Project Selector Dropdown */}
          <div className="relative group hidden sm:block">
            <button
              onClick={() => setShowProjectDropdown(!showProjectDropdown)}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-surface-container dark:hover:bg-[#2e3132] transition-colors border border-transparent hover:border-outline-variant"
            >
              <span className="w-2 h-2 rounded-full bg-secondary"></span>
              <span className="font-semibold text-sm text-on-surface dark:text-[#f0f1f2] max-w-[160px] md:max-w-[220px] truncate">
                {currentProject.name}
              </span>
              <span className="material-symbols-outlined text-on-surface-variant text-lg">
                expand_more
              </span>
            </button>

            {showProjectDropdown && (
              <div className="absolute left-0 mt-1 w-72 bg-surface dark:bg-[#2e3132] rounded-xl shadow-xl border border-surface-variant dark:border-outline p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="text-xs font-semibold text-on-surface-variant px-3 py-2 uppercase tracking-wider">
                  {t.projectSpace}
                </div>
                <div className="space-y-1">
                  {projects.map((proj) => (
                    <button
                      key={proj.id}
                      onClick={() => {
                        onSelectProject(proj);
                        setShowProjectDropdown(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                        proj.id === currentProject.id
                          ? 'bg-primary-fixed/30 text-primary dark:text-[#adc6ff] font-semibold'
                          : 'hover:bg-surface-container-low dark:hover:bg-[#191c1d] text-on-surface dark:text-[#f0f1f2]'
                      }`}
                    >
                      <span
                        className="w-3 h-3 rounded-full flex-shrink-0"
                        style={{ backgroundColor: proj.color }}
                      ></span>
                      <div className="flex flex-col truncate">
                        <span className="text-sm truncate">{proj.name}</span>
                        <span className="text-[11px] text-on-surface-variant truncate">
                          {proj.description}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Global Search Bar */}
          <div className="hidden md:flex ml-2 lg:ml-6 items-center bg-surface-container dark:bg-[#2e3132] rounded-full px-3 py-1.5 w-48 lg:w-64 border border-transparent focus-within:border-primary focus-within:ring-1 focus-within:ring-primary transition-all">
            <span className="material-symbols-outlined text-on-surface-variant mr-1 text-sm">
              search
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="bg-transparent border-none focus:outline-none focus:ring-0 text-sm w-full text-on-surface dark:text-[#f0f1f2] placeholder-on-surface-variant"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="text-on-surface-variant hover:text-on-surface text-xs"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Right Section: Actions & Avatar */}
        <div className="flex items-center gap-2 md:gap-3">
          {/* Quick Create Task Button */}
          {onOpenNewTask && (
            <button
              onClick={onOpenNewTask}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary text-on-primary font-bold text-xs shadow-xs hover:opacity-90 active:scale-95 transition-all cursor-pointer"
              title={lang === 'zh' ? '快速创建任务 (Alt+N)' : 'Quick Create Task (Alt+N)'}
            >
              <span className="material-symbols-outlined text-base">add_task</span>
              <span>{lang === 'zh' ? '快速新建' : 'Quick Task'}</span>
            </button>
          )}

          {/* Language Switcher */}
          <button
            onClick={onToggleLang}
            className="px-2.5 py-1 rounded-lg border border-outline-variant hover:bg-surface-container dark:hover:bg-[#2e3132] transition-colors text-xs font-semibold text-primary dark:text-[#adc6ff] flex items-center gap-1 shadow-sm"
            title="Switch Language / 切换中英文"
          >
            <span className="material-symbols-outlined text-sm">translate</span>
            <span>{lang === 'zh' ? '中文 / EN' : 'EN / 中文'}</span>
          </button>

          {/* Notifications Button */}
          <div className="relative">
            <button
              onClick={() => {
                if (onOpenNotifications) {
                  onOpenNotifications();
                } else {
                  setShowNotifDropdown(!showNotifDropdown);
                  setShowUserDropdown(false);
                }
              }}
              className="p-2 rounded-full hover:bg-surface-container dark:hover:bg-[#2e3132] text-on-surface-variant hover:text-primary transition-colors relative cursor-pointer"
            >
              <span className="material-symbols-outlined">notifications</span>
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-error ring-2 ring-surface animate-pulse"></span>
            </button>

            {showNotifDropdown && (
              <div className="absolute right-0 mt-2 w-80 bg-surface dark:bg-[#2e3132] rounded-xl shadow-xl border border-surface-variant dark:border-outline p-4 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="flex justify-between items-center mb-3 pb-2 border-b border-surface-variant">
                  <span className="font-bold text-sm text-on-surface dark:text-[#f0f1f2]">
                    {lang === 'zh' ? '系统通知' : 'Notifications'}
                  </span>
                  <span className="text-xs text-primary cursor-pointer hover:underline">
                    {lang === 'zh' ? '标为已读' : 'Mark all read'}
                  </span>
                </div>
                <div className="space-y-3">
                  <div className="flex gap-3 text-xs">
                    <span className="w-2 h-2 rounded-full bg-primary mt-1.5 flex-shrink-0"></span>
                    <div>
                      <p className="font-medium text-on-surface dark:text-[#f0f1f2]">
                        {lang === 'zh' ? '技术调研文档需今日 17:00 前提交评审' : 'Design doc due today at 17:00'}
                      </p>
                      <p className="text-on-surface-variant mt-0.5">10 {lang === 'zh' ? '分钟前' : 'mins ago'}</p>
                    </div>
                  </div>
                  <div className="flex gap-3 text-xs">
                    <span className="w-2 h-2 rounded-full bg-secondary mt-1.5 flex-shrink-0"></span>
                    <div>
                      <p className="font-medium text-on-surface dark:text-[#f0f1f2]">
                        {lang === 'zh' ? 'Marcus Vance 完成了 API 认证层重构' : 'Marcus Vance completed API Auth refactor'}
                      </p>
                      <p className="text-on-surface-variant mt-0.5">1 {lang === 'zh' ? '小时前' : 'hour ago'}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Help Button */}
          <button
            onClick={() => setShowHelpModal(true)}
            className="p-2 rounded-full hover:bg-surface-container dark:hover:bg-[#2e3132] text-on-surface-variant hover:text-primary transition-colors hidden sm:block"
          >
            <span className="material-symbols-outlined">help_outline</span>
          </button>

          {/* User Avatar */}
          <div className="relative">
            <button
              onClick={() => {
                setShowUserDropdown(!showUserDropdown);
                setShowNotifDropdown(false);
              }}
              className="flex items-center gap-2 p-1 rounded-full hover:bg-surface-container dark:hover:bg-[#2e3132] transition-colors border border-outline-variant"
            >
              <img
                src={user.avatar}
                alt={user.name}
                className="w-8 h-8 rounded-full object-cover"
                onError={(e) => {
                  // Fallback if image fails
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <span className="w-2 h-2 rounded-full bg-secondary absolute bottom-1 right-1 ring-2 ring-surface"></span>
            </button>

            {showUserDropdown && (
              <div className="absolute right-0 mt-2 w-64 bg-surface dark:bg-[#2e3132] rounded-xl shadow-xl border border-surface-variant dark:border-outline p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3 py-3 border-b border-surface-variant mb-1 flex items-center gap-3">
                  <img src={user.avatar} alt="" className="w-10 h-10 rounded-full object-cover" />
                  <div className="overflow-hidden">
                    <p className="font-bold text-sm text-on-surface dark:text-[#f0f1f2] truncate">
                      {user.name}
                    </p>
                    <p className="text-xs text-on-surface-variant truncate">{user.email}</p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    onOpenSettings();
                    setShowUserDropdown(false);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-surface-container-low dark:hover:bg-[#191c1d] text-sm text-on-surface dark:text-[#f0f1f2] transition-colors"
                >
                  <span className="material-symbols-outlined text-lg">settings</span>
                  <span>{t.settings}</span>
                </button>

                <button
                  onClick={() => {
                    onResetDemo();
                    setShowUserDropdown(false);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-surface-container-low dark:hover:bg-[#191c1d] text-sm text-secondary transition-colors"
                >
                  <span className="material-symbols-outlined text-lg">restart_alt</span>
                  <span>{t.resetDemo}</span>
                </button>

                <div className="border-t border-surface-variant my-1 pt-1">
                  <button
                    onClick={() => {
                      alert(lang === 'zh' ? '已安全退出登录演示' : 'Signed out of demo session');
                      setShowUserDropdown(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-error-container/20 text-sm text-error transition-colors font-medium"
                  >
                    <span className="material-symbols-outlined text-lg">logout</span>
                    <span>{t.signOut}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Help Modal */}
      {showHelpModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-surface dark:bg-[#2e3132] rounded-2xl max-w-md w-full p-6 shadow-2xl border border-surface-variant">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-lg text-on-surface dark:text-[#f0f1f2] flex items-center gap-2">
                <span className="material-symbols-outlined text-primary">lightbulb</span>
                {lang === 'zh' ? 'Flow 使用指导与快捷键' : 'Flow Shortcuts & Tips'}
              </h3>
              <button
                onClick={() => setShowHelpModal(false)}
                className="p-1 rounded-full hover:bg-surface-container text-on-surface-variant"
              >
                ✕
              </button>
            </div>
            <div className="space-y-3 text-sm text-on-surface-variant">
              <div className="p-3 bg-surface-container-low dark:bg-[#191c1d] rounded-xl flex justify-between items-center">
                <span>{lang === 'zh' ? '快速新建任务' : 'Quick Create Task'}</span>
                <kbd className="px-2 py-1 bg-surface border border-outline-variant rounded text-xs font-mono">
                  Alt + N
                </kbd>
              </div>
              <div className="p-3 bg-surface-container-low dark:bg-[#191c1d] rounded-xl flex justify-between items-center">
                <span>{lang === 'zh' ? '看板卡片拖拽' : 'Kanban Card Drag'}</span>
                <span className="text-xs text-primary font-medium">{lang === 'zh' ? '支持直接按住拖移' : 'Drag & drop supported'}</span>
              </div>
              <div className="p-3 bg-surface-container-low dark:bg-[#191c1d] rounded-xl flex justify-between items-center">
                <span>{lang === 'zh' ? '双语一键切换' : 'Bilingual Toggle'}</span>
                <span className="text-xs font-semibold">EN / 中文</span>
              </div>
            </div>
            <button
              onClick={() => setShowHelpModal(false)}
              className="mt-6 w-full py-2.5 bg-primary text-on-primary rounded-xl font-semibold text-sm shadow-md hover:opacity-90 transition-opacity"
            >
              {lang === 'zh' ? '知道了' : 'Got it'}
            </button>
          </div>
        </div>
      )}
    </>
  );
};
