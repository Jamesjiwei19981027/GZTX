import React, { useState } from 'react';
import { NotificationItem, Language } from '../../types';
import { loadNotifications, saveNotifications } from '../../data/mockData';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTaskId?: (taskId: string) => void;
  onOpenSettings?: () => void;
  lang: Language;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onSelectTaskId,
  onOpenSettings,
  lang,
}) => {
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => loadNotifications());
  const [activeTab, setActiveTab] = useState<'all' | 'unread'>('all');

  if (!isOpen) return null;

  const handleMarkAsRead = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = notifications.map((n) => (n.id === id ? { ...n, read: true } : n));
    setNotifications(updated);
    saveNotifications(updated);
  };

  const handleMarkAllRead = () => {
    const updated = notifications.map((n) => ({ ...n, read: true }));
    setNotifications(updated);
    saveNotifications(updated);
  };

  const handleClearAll = () => {
    setNotifications([]);
    saveNotifications([]);
  };

  const handleNotificationClick = (item: NotificationItem) => {
    if (!item.read) {
      const updated = notifications.map((n) => (n.id === item.id ? { ...n, read: true } : n));
      setNotifications(updated);
      saveNotifications(updated);
    }
    if (item.linkTaskId && onSelectTaskId) {
      onSelectTaskId(item.linkTaskId);
      onClose();
    }
  };

  const filteredNotifications = notifications.filter((n) => (activeTab === 'unread' ? !n.read : true));
  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in">
      <div className="bg-surface-container-lowest dark:bg-[#191c1d] w-full max-w-xl rounded-3xl border border-outline-variant/40 shadow-2xl flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-outline-variant/20 flex items-center justify-between bg-surface-container/20">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-primary/10 text-primary flex items-center justify-center">
              <span className="material-symbols-outlined text-2xl">notifications_active</span>
            </div>
            <div>
              <h2 className="text-lg font-bold text-on-surface flex items-center gap-2">
                {lang === 'zh' ? '通知中心 (Notification Center)' : 'Notification Center'}
                {unreadCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-error text-on-error text-xs font-bold">
                    {unreadCount} {lang === 'zh' ? '未读' : 'new'}
                  </span>
                )}
              </h2>
              <p className="text-xs text-on-surface-variant">
                {lang === 'zh' ? '查看项目进度流转、提及与预警消息' : 'Stay updated on mentions, assignments, and deadlines.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {onOpenSettings && (
              <button
                onClick={() => {
                  onClose();
                  onOpenSettings();
                }}
                className="p-2 rounded-xl text-on-surface-variant hover:text-on-surface hover:bg-surface-container transition-colors"
                title={lang === 'zh' ? '通知与提醒设置' : 'Notification Settings'}
              >
                <span className="material-symbols-outlined text-lg">settings</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-on-surface-variant hover:text-on-surface hover:bg-surface-container transition-colors"
            >
              <span className="material-symbols-outlined text-lg">close</span>
            </button>
          </div>
        </div>

        {/* Filter Tabs & Bulk Actions */}
        <div className="px-6 py-3 bg-surface-container-low border-b border-outline-variant/20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'all'
                  ? 'bg-primary text-on-primary shadow-xs'
                  : 'text-on-surface-variant hover:bg-surface-container'
              }`}
            >
              {lang === 'zh' ? '全部消息' : 'All'} ({notifications.length})
            </button>
            <button
              onClick={() => setActiveTab('unread')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'unread'
                  ? 'bg-primary text-on-primary shadow-xs'
                  : 'text-on-surface-variant hover:bg-surface-container'
              }`}
            >
              {lang === 'zh' ? '未读提示' : 'Unread'} ({unreadCount})
            </button>
          </div>

          <div className="flex items-center gap-3">
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                className="text-xs font-semibold text-primary hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-sm">done_all</span>
                {lang === 'zh' ? '全部设为已读' : 'Mark all read'}
              </button>
            )}
            {notifications.length > 0 && (
              <button
                onClick={handleClearAll}
                className="text-xs font-semibold text-error hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span className="material-symbols-outlined text-sm">delete_sweep</span>
                {lang === 'zh' ? '清空' : 'Clear'}
              </button>
            )}
          </div>
        </div>

        {/* Notifications Feed */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3 max-h-[420px]">
          {filteredNotifications.length === 0 ? (
            <div className="py-12 text-center text-on-surface-variant text-sm">
              ✨ {lang === 'zh' ? '没有符合条件的通知，工作台非常整洁！' : 'No notifications found. All caught up!'}
            </div>
          ) : (
            filteredNotifications.map((item) => (
              <div
                key={item.id}
                onClick={() => handleNotificationClick(item)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start justify-between gap-4 ${
                  !item.read
                    ? 'bg-primary-container/10 border-primary/40 shadow-xs hover:bg-primary-container/20'
                    : 'bg-surface-container-low border-outline-variant/30 opacity-80 hover:opacity-100'
                }`}
              >
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                      item.type === 'assignment'
                        ? 'bg-primary/10 text-primary'
                        : item.type === 'mention'
                        ? 'bg-tertiary/10 text-tertiary'
                        : item.type === 'deadline'
                        ? 'bg-error/10 text-error'
                        : 'bg-secondary/10 text-secondary'
                    }`}
                  >
                    <span className="material-symbols-outlined text-lg">
                      {item.type === 'assignment'
                        ? 'assignment_ind'
                        : item.type === 'mention'
                        ? 'alternate_email'
                        : item.type === 'deadline'
                        ? 'alarm'
                        : 'info'}
                    </span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className={`text-sm truncate ${!item.read ? 'font-extrabold text-on-surface' : 'font-bold text-on-surface/90'}`}>
                        {item.title}
                      </h4>
                      <span className="text-[10px] text-on-surface-variant shrink-0 font-mono">{item.timestamp}</span>
                    </div>
                    <p className="text-xs text-on-surface-variant mt-1 leading-relaxed">{item.message}</p>
                    {item.linkTaskId && (
                      <div className="mt-2 inline-flex items-center gap-1 text-[11px] font-bold text-primary bg-primary/10 px-2.5 py-0.5 rounded-lg">
                        <span className="material-symbols-outlined text-xs">launch</span>
                        {lang === 'zh' ? '点击查看关联看板卡片' : 'View related task'}
                      </div>
                    )}
                  </div>
                </div>

                {!item.read && (
                  <button
                    onClick={(e) => handleMarkAsRead(item.id, e)}
                    className="p-1.5 rounded-lg text-primary hover:bg-primary/10 transition-colors shrink-0"
                    title={lang === 'zh' ? '标注为已读' : 'Mark read'}
                  >
                    <span className="w-2.5 h-2.5 rounded-full bg-primary block" />
                  </button>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-outline-variant/20 bg-surface-container/10 flex items-center justify-between text-xs text-on-surface-variant">
          <span>{lang === 'zh' ? '支持自动推送项目进度与逾期提醒' : 'Real-time alert notifications enabled.'}</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-primary text-on-primary font-bold shadow-xs hover:opacity-90 transition-all cursor-pointer"
          >
            {lang === 'zh' ? '关闭' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
