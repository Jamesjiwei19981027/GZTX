import React, { useState } from 'react';
import { IntegrationItem, Language } from '../../types';
import { loadIntegrations, saveIntegrations } from '../../data/mockData';

interface InboxViewProps {
  onOpenNewTaskWithTitle?: (title: string, desc: string) => void;
  lang: Language;
}

export const InboxView: React.FC<InboxViewProps> = ({ onOpenNewTaskWithTitle, lang }) => {
  const [integrations, setIntegrations] = useState<IntegrationItem[]>(() => loadIntegrations());
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Simulated incoming external inbox items (Emails, Slack mentions, GitHub PR reviews)
  const [inboxItems, setInboxItems] = useState([
    {
      id: 'inbox_1',
      source: 'Gmail',
      icon: 'mail',
      sender: 'David Clark (Client Partner)',
      subject: '关于 Q3 季度企业版私有化部署的安全审计需求更新',
      snippet: '你好 Alex，随信附上最新的渗透测试白皮书，请安排安全组工程师在下周三前回顾验收...',
      timestamp: '10:15 AM',
      tag: 'Urgent',
    },
    {
      id: 'inbox_2',
      source: 'GitHub CI/CD',
      icon: 'code',
      sender: 'GitHub Actions Bot',
      subject: 'PR #418: [Refactor] Auth Gateway Middleware Failed Build #809',
      snippet: 'Unit test suite failed on module src/middleware/token.spec.ts. Please review stack trace...',
      timestamp: 'Yesterday',
      tag: 'Bug',
    },
    {
      id: 'inbox_3',
      source: 'Slack Bot',
      icon: 'chat',
      sender: '#prod-announcements',
      subject: '用户反馈：iOS 客户端在低电量模式下看板滑屏轻微卡顿',
      snippet: '设计与移动组请协同检查 CoreAnimation 帧率限制，尽快发布 V2.4.1 Hotfix Patch...',
      timestamp: '2 days ago',
      tag: 'Feature',
    },
  ]);

  const handleToggleConnection = (id: string) => {
    const updated = integrations.map((item) => {
      if (item.id === id) {
        return {
          ...item,
          connected: !item.connected,
          lastSync: !item.connected ? '刚刚同步 (Synced now)' : undefined,
        };
      }
      return item;
    });
    setIntegrations(updated);
    saveIntegrations(updated);
  };

  const handleSyncNow = (id: string) => {
    const updated = integrations.map((item) => {
      if (item.id === id) {
        return { ...item, lastSync: '刚刚自动同步 (Just now)' };
      }
      return item;
    });
    setIntegrations(updated);
    saveIntegrations(updated);
    alert(lang === 'zh' ? '应用连接已触发实时同步！' : 'Integration synced successfully!');
  };

  const handleConvertToTask = (item: typeof inboxItems[0]) => {
    if (onOpenNewTaskWithTitle) {
      onOpenNewTaskWithTitle(item.subject, `[来自 ${item.source}] ${item.snippet}`);
    } else {
      alert(lang === 'zh' ? `已将「${item.subject}」转化为待办任务！` : `Converted "${item.subject}" to task!`);
    }
    setInboxItems((prev) => prev.filter((i) => i.id !== item.id));
  };

  const handleDismiss = (id: string) => {
    setInboxItems((prev) => prev.filter((i) => i.id !== id));
  };

  const categories = [
    { id: 'all', labelZh: '全部应用工具', labelEn: 'All Integrations' },
    { id: 'Communication', labelZh: '沟通与邮件', labelEn: 'Communication' },
    { id: 'Development', labelZh: '代码研发与设计', labelEn: 'Development' },
    { id: 'Storage', labelZh: '云端盘与日历', labelEn: 'Storage & Calendar' },
  ];

  const filteredIntegrations = integrations.filter(
    (item) => selectedCategory === 'all' || item.category === selectedCategory || (selectedCategory === 'Storage' && item.category === 'Calendar')
  );

  return (
    <div className="space-y-8 animate-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface-container-low p-6 rounded-3xl border border-outline-variant/30 shadow-xs">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-on-surface flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-3xl">all_inbox</span>
            {lang === 'zh' ? '收件箱与第三方生产力应用集成' : 'Inbox & Workspace Integrations'}
          </h1>
          <p className="text-sm text-on-surface-variant mt-1">
            {lang === 'zh'
              ? '无缝连接 Gmail、GitHub、Slack 与 Google Calendar，自动聚合工作流通知转化为看板待办项'
              : 'Connect Gmail, Slack, GitHub, and Google Drive to sync notifications into actionable tasks.'}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="px-3 py-1.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold flex items-center gap-1.5 border border-emerald-500/20">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            {lang === 'zh' ? '网关监听中' : 'Gateway Active'}
          </span>
        </div>
      </div>

      {/* Incoming Messages / Action Tray */}
      <div className="bg-surface-container-lowest p-6 rounded-3xl border border-outline-variant/30 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-tertiary text-xl">mark_email_unread</span>
            <h2 className="text-lg font-bold text-on-surface">
              {lang === 'zh' ? '待处理外部工单与邮件流 (Incoming Queue)' : 'Incoming Action Queue'}
            </h2>
            <span className="px-2 py-0.5 rounded-full bg-tertiary/10 text-tertiary text-xs font-bold">
              {inboxItems.length}
            </span>
          </div>
          <span className="text-xs text-on-surface-variant">
            {lang === 'zh' ? '支持一键转化为右侧看板卡片' : '1-click convert to task'}
          </span>
        </div>

        {inboxItems.length === 0 ? (
          <div className="py-8 text-center text-on-surface-variant text-sm">
            🎉 {lang === 'zh' ? '太棒了！所有第三方收件箱事项已全部转化处理完毕' : 'All incoming queue items processed!'}
          </div>
        ) : (
          <div className="space-y-3">
            {inboxItems.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-surface-container-low border border-outline-variant/30 hover:border-primary/40 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 group"
              >
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0 mt-0.5">
                    <span className="material-symbols-outlined">{item.icon}</span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-primary">{item.source}</span>
                      <span className="text-xs text-on-surface-variant">• {item.sender}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-surface-container-highest text-on-surface-variant font-medium">
                        {item.timestamp}
                      </span>
                    </div>
                    <h4 className="text-sm font-bold text-on-surface mt-1 truncate group-hover:text-primary transition-colors">
                      {item.subject}
                    </h4>
                    <p className="text-xs text-on-surface-variant mt-0.5 line-clamp-1">{item.snippet}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                  <button
                    onClick={() => handleConvertToTask(item)}
                    className="px-4 py-2 rounded-xl bg-primary text-on-primary text-xs font-bold shadow-xs hover:opacity-90 active:scale-95 transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-sm">add_task</span>
                    {lang === 'zh' ? '转为待办任务' : 'Convert to Task'}
                  </button>
                  <button
                    onClick={() => handleDismiss(item.id)}
                    className="p-2 rounded-xl bg-surface-container hover:bg-error/10 hover:text-error text-on-surface-variant transition-colors cursor-pointer"
                    title={lang === 'zh' ? '忽略并归档' : 'Dismiss'}
                  >
                    <span className="material-symbols-outlined text-sm">delete</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Filter Bar for Integrations */}
      <div className="flex items-center gap-2 overflow-x-auto bg-surface-container-lowest p-2 rounded-2xl border border-outline-variant/30">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-4 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCategory === cat.id
                ? 'bg-primary text-on-primary font-bold shadow-xs'
                : 'text-on-surface-variant hover:bg-surface-container-high'
            }`}
          >
            {lang === 'zh' ? cat.labelZh : cat.labelEn}
          </button>
        ))}
      </div>

      {/* Integrations Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredIntegrations.map((item) => (
          <div
            key={item.id}
            className={`bg-surface-container-lowest rounded-3xl p-6 border transition-all flex flex-col justify-between ${
              item.connected
                ? 'border-primary/30 shadow-xs hover:shadow-md'
                : 'border-outline-variant/30 opacity-80 hover:opacity-100'
            }`}
          >
            <div>
              <div className="flex items-start justify-between">
                <div className="w-12 h-12 rounded-2xl bg-surface-container-high flex items-center justify-center text-primary">
                  <span className="material-symbols-outlined text-2xl">{item.icon}</span>
                </div>
                {item.connected ? (
                  <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold flex items-center gap-1 border border-emerald-500/20">
                    <span className="material-symbols-outlined text-xs">check_circle</span>
                    {lang === 'zh' ? '已授权连接' : 'Connected'}
                  </span>
                ) : (
                  <span className="px-2.5 py-1 rounded-full bg-surface-container-highest text-on-surface-variant text-xs font-medium">
                    {lang === 'zh' ? '未连接' : 'Disconnected'}
                  </span>
                )}
              </div>

              <h3 className="text-lg font-bold text-on-surface mt-4">{item.name}</h3>
              <p className="text-xs text-on-surface-variant mt-2 leading-relaxed min-h-[36px]">
                {item.description}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-outline-variant/20 flex items-center justify-between">
              <span className="text-[11px] text-on-surface-variant">
                {item.connected ? `${lang === 'zh' ? '同步状态:' : 'Synced:'} ${item.lastSync || '刚刚'}` : ''}
              </span>
              <div className="flex items-center gap-2">
                {item.connected && (
                  <button
                    onClick={() => handleSyncNow(item.id)}
                    className="p-2 rounded-xl bg-surface-container hover:bg-surface-container-high text-on-surface transition-colors cursor-pointer"
                    title={lang === 'zh' ? '立刻手动同步' : 'Sync Now'}
                  >
                    <span className="material-symbols-outlined text-sm">sync</span>
                  </button>
                )}
                <button
                  onClick={() => handleToggleConnection(item.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    item.connected
                      ? 'bg-surface-container-highest text-error hover:bg-error/10'
                      : 'bg-primary text-on-primary shadow-xs hover:opacity-90'
                  }`}
                >
                  {item.connected ? (lang === 'zh' ? '断开连接' : 'Disconnect') : (lang === 'zh' ? '立即连接 (Connect)' : 'Connect')}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
