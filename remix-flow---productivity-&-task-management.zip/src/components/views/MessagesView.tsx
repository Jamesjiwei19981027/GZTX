import React, { useState } from 'react';
import { MessageItem, Language, UserProfile } from '../../types';
import { loadMessages, saveMessages, TEAM_MEMBERS } from '../../data/mockData';

interface MessagesViewProps {
  user: UserProfile;
  lang: Language;
}

export const MessagesView: React.FC<MessagesViewProps> = ({ user, lang }) => {
  const [messages, setMessages] = useState<MessageItem[]>(() => loadMessages());
  const [activeChannel, setActiveChannel] = useState<'general' | 'project' | 'direct'>('general');
  const [inputText, setInputText] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const channels = [
    { id: 'general' as const, labelZh: '# 全员交流大厅 (General)', labelEn: '# general-lobby', icon: 'tag' },
    { id: 'project' as const, labelZh: '# 研发架构冲刺组 (Project)', labelEn: '# project-sprint', icon: 'tag' },
    { id: 'direct' as const, labelZh: '@ 私信与提及 (@Direct)', labelEn: '@ mentions-direct', icon: 'alternate_email' },
  ];

  const filteredMessages = messages.filter((msg) => {
    const matchesChannel = msg.channel === activeChannel;
    const matchesSearch =
      !searchQuery ||
      msg.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      msg.senderName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesChannel && matchesSearch;
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newMsg: MessageItem = {
      id: `msg_${Date.now()}`,
      senderName: user.name,
      senderAvatar: user.avatar,
      content: inputText.trim(),
      timestamp: lang === 'zh' ? '刚刚 (Just now)' : 'Just now',
      channel: activeChannel,
      likes: 0,
      repliesCount: 0,
    };

    const updated = [...messages, newMsg];
    setMessages(updated);
    saveMessages(updated);
    setInputText('');
  };

  const handleLike = (id: string) => {
    const updated = messages.map((msg) => {
      if (msg.id === id) {
        return { ...msg, likes: (msg.likes || 0) + 1 };
      }
      return msg;
    });
    setMessages(updated);
    saveMessages(updated);
  };

  return (
    <div className="space-y-6 animate-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface-container-low p-6 rounded-3xl border border-outline-variant/30 shadow-xs">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-on-surface flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-3xl">forum</span>
            {lang === 'zh' ? '消息中心与团队实时沟通空间' : 'Messages & Team Communication'}
          </h1>
          <p className="text-sm text-on-surface-variant mt-1">
            {lang === 'zh'
              ? '跨时区、跨部门团队的高效在线议题讨论、任务指派提醒与实时反馈群聊'
              : 'Real-time team discussions, project updates, and direct notifications.'}
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-bold">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            {lang === 'zh' ? '实时会话连通' : 'Live Chat Connected'}
          </span>
        </div>
      </div>

      {/* Main Chat Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 min-h-[600px]">
        {/* Left Channel Sidebar */}
        <div className="bg-surface-container-lowest p-5 rounded-3xl border border-outline-variant/30 shadow-xs flex flex-col justify-between">
          <div>
            <div className="relative mb-4">
              <span className="material-symbols-outlined absolute left-3 top-2.5 text-outline text-lg">search</span>
              <input
                type="text"
                placeholder={lang === 'zh' ? '搜索聊天内容...' : 'Search messages...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs rounded-xl bg-surface-container border border-outline-variant/40 focus:outline-none focus:ring-2 focus:ring-primary/40 text-on-surface"
              />
            </div>

            <h3 className="text-xs font-bold uppercase tracking-wider text-on-surface-variant px-2 mb-2">
              {lang === 'zh' ? '沟通频道 (Channels)' : 'Channels'}
            </h3>
            <div className="space-y-1">
              {channels.map((chan) => (
                <button
                  key={chan.id}
                  onClick={() => setActiveChannel(chan.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-2xl text-xs font-semibold transition-all cursor-pointer ${
                    activeChannel === chan.id
                      ? 'bg-primary text-on-primary font-bold shadow-xs'
                      : 'text-on-surface-variant hover:bg-surface-container-high hover:text-on-surface'
                  }`}
                >
                  <span className="material-symbols-outlined text-base">{chan.icon}</span>
                  <span className="truncate">{lang === 'zh' ? chan.labelZh : chan.labelEn}</span>
                </button>
              ))}
            </div>

            <h3 className="text-xs font-bold uppercase tracking-wider text-on-surface-variant px-2 mt-6 mb-2">
              {lang === 'zh' ? '在线协作成员 (Online)' : 'Online Members'}
            </h3>
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {TEAM_MEMBERS.map((m) => (
                <div key={m.id} className="flex items-center gap-2.5 px-2 py-1.5 rounded-xl text-xs">
                  <div className="relative shrink-0">
                    <img src={m.avatar} alt={m.name} className="w-7 h-7 rounded-full object-cover" />
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-surface absolute -bottom-0.5 -right-0.5" />
                  </div>
                  <div className="truncate">
                    <p className="font-semibold text-on-surface truncate">{m.name}</p>
                    <p className="text-[10px] text-on-surface-variant truncate">{m.role}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-outline-variant/20">
            <div className="flex items-center justify-between text-xs text-on-surface-variant">
              <span>{lang === 'zh' ? '当前频道活跃度' : 'Channel Activity'}</span>
              <span className="font-bold text-primary">HIGH</span>
            </div>
          </div>
        </div>

        {/* Right Message Stream & Input Area */}
        <div className="lg:col-span-3 bg-surface-container-lowest rounded-3xl border border-outline-variant/30 shadow-xs flex flex-col justify-between">
          {/* Channel Header Banner */}
          <div className="p-5 border-b border-outline-variant/20 flex items-center justify-between bg-surface-container/30 rounded-t-3xl">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-primary text-2xl">
                {channels.find((c) => c.id === activeChannel)?.icon}
              </span>
              <div>
                <h3 className="font-bold text-on-surface text-base">
                  {channels.find((c) => c.id === activeChannel)?.[lang === 'zh' ? 'labelZh' : 'labelEn']}
                </h3>
                <p className="text-xs text-on-surface-variant">
                  {activeChannel === 'general'
                    ? lang === 'zh'
                      ? '全员共享进度、系统公告与头脑风暴区'
                      : 'Company-wide announcements and progress sharing.'
                    : activeChannel === 'project'
                    ? lang === 'zh'
                      ? '核心架构迭代冲刺与代码联调集中讨论组'
                      : 'Core architecture and sprint discussions.'
                    : lang === 'zh'
                    ? '仅限你参与的私信沟通与直接 @ 提醒消息'
                    : 'Direct messages and task mentions.'}
                </p>
              </div>
            </div>
          </div>

          {/* Messages List */}
          <div className="p-6 space-y-6 flex-1 overflow-y-auto max-h-[480px]">
            {filteredMessages.length === 0 ? (
              <div className="py-16 text-center text-on-surface-variant text-sm">
                📭 {lang === 'zh' ? '暂无聊天记录，快在下方发送第一条团队消息吧！' : 'No messages here yet. Start the conversation!'}
              </div>
            ) : (
              filteredMessages.map((msg) => (
                <div key={msg.id} className="flex items-start gap-4 group">
                  <img src={msg.senderAvatar} alt={msg.senderName} className="w-10 h-10 rounded-2xl object-cover shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline gap-2">
                      <span className="font-bold text-sm text-on-surface">{msg.senderName}</span>
                      <span className="text-[11px] text-on-surface-variant font-mono">{msg.timestamp}</span>
                    </div>
                    <div className="mt-1.5 p-3.5 rounded-2xl bg-surface-container-low border border-outline-variant/20 text-sm text-on-surface leading-relaxed inline-block max-w-2xl">
                      {msg.content}
                    </div>

                    {/* Like & Reply action bar */}
                    <div className="mt-1.5 flex items-center gap-3">
                      <button
                        onClick={() => handleLike(msg.id)}
                        className="flex items-center gap-1 text-xs font-semibold text-on-surface-variant hover:text-primary px-2 py-0.5 rounded-lg hover:bg-surface-container transition-all cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-sm">thumb_up</span>
                        <span>{msg.likes && msg.likes > 0 ? msg.likes : lang === 'zh' ? '点赞' : 'Like'}</span>
                      </button>
                      <button
                        onClick={() => alert(lang === 'zh' ? '已展开评论回复框' : 'Reply box opened')}
                        className="flex items-center gap-1 text-xs font-semibold text-on-surface-variant hover:text-primary px-2 py-0.5 rounded-lg hover:bg-surface-container transition-all cursor-pointer"
                      >
                        <span className="material-symbols-outlined text-sm">reply</span>
                        <span>
                          {msg.repliesCount && msg.repliesCount > 0 ? `${msg.repliesCount} ${lang === 'zh' ? '条回复' : 'replies'}` : lang === 'zh' ? '回复' : 'Reply'}
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Message Input Form */}
          <form onSubmit={handleSendMessage} className="p-4 border-t border-outline-variant/20 bg-surface-container/20 rounded-b-3xl">
            <div className="flex items-center gap-2 bg-surface p-2 rounded-2xl border border-outline-variant/40 focus-within:ring-2 focus-within:ring-primary/40 focus-within:border-primary transition-all">
              <button
                type="button"
                onClick={() => alert(lang === 'zh' ? '已选择附加文件图表' : 'Attachment selected')}
                className="p-2 rounded-xl text-on-surface-variant hover:text-on-surface hover:bg-surface-container transition-colors"
                title={lang === 'zh' ? '附加文件或截图' : 'Attach file'}
              >
                <span className="material-symbols-outlined text-lg">attach_file</span>
              </button>
              <input
                type="text"
                placeholder={lang === 'zh' ? '输入讨论内容... (可使用 @ 提及团队成员)' : 'Type a message to the team...'}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                className="flex-1 px-2 py-1.5 text-sm bg-transparent focus:outline-none text-on-surface placeholder:text-on-surface-variant"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className={`px-5 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                  inputText.trim()
                    ? 'bg-primary text-on-primary shadow-xs hover:opacity-90'
                    : 'bg-surface-container-highest text-on-surface-variant opacity-50 cursor-not-allowed'
                }`}
              >
                <span>{lang === 'zh' ? '发送' : 'Send'}</span>
                <span className="material-symbols-outlined text-sm">send</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
