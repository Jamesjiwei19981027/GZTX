import React, { useState } from 'react';
import { TeamMember, Language } from '../../types';
import { TEAM_MEMBERS } from '../../data/mockData';

interface TeamViewProps {
  onSelectMember?: (member: TeamMember) => void;
  onNavigateToMessages?: () => void;
  lang: Language;
}

export const TeamView: React.FC<TeamViewProps> = ({ onNavigateToMessages, lang }) => {
  const [members, setMembers] = useState<TeamMember[]>(TEAM_MEMBERS);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [isInviteOpen, setIsInviteOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('Senior Engineer');

  const departments = [
    { id: 'all', labelZh: '全部部门', labelEn: 'All Departments' },
    { id: 'Engineering', labelZh: '基础架构与研发', labelEn: 'Engineering' },
    { id: 'Design', labelZh: '设计体验部', labelEn: 'Design' },
    { id: 'Product', labelZh: '产品研发组', labelEn: 'Product' },
  ];

  const filteredMembers = members.filter((member) => {
    const matchesQuery =
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (member.department && member.department.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesDept =
      selectedDept === 'all' || (member.department && member.department.includes(selectedDept));
    return matchesQuery && matchesDept;
  });

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail.trim()) return;
    const newMember: TeamMember = {
      id: `m_${Date.now()}`,
      name: inviteEmail.split('@')[0].replace('.', ' '),
      role: inviteRole,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      status: 'online',
      department: 'Engineering (新进协作成员)',
      email: inviteEmail,
      tasksCount: 0,
    };
    setMembers((prev) => [newMember, ...prev]);
    setInviteEmail('');
    setIsInviteOpen(false);
  };

  const statusBadge = (status?: string) => {
    switch (status) {
      case 'online':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            {lang === 'zh' ? '在线协作' : 'Online'}
          </span>
        );
      case 'busy':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            {lang === 'zh' ? '攻坚冲刺' : 'Busy'}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-500/10 text-slate-500 dark:text-slate-400 border border-slate-500/20">
            <span className="w-2 h-2 rounded-full bg-slate-400" />
            {lang === 'zh' ? '离线休息' : 'Offline'}
          </span>
        );
    }
  };

  return (
    <div className="space-y-8 animate-in pb-12">
      {/* Header & Invite Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface-container-low p-6 rounded-3xl border border-outline-variant/30 shadow-xs">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-on-surface flex items-center gap-2">
            <span className="material-symbols-outlined text-primary text-3xl">groups</span>
            {lang === 'zh' ? '团队协作空间与核心成员' : 'Team Directory & Collaborators'}
          </h1>
          <p className="text-sm text-on-surface-variant mt-1">
            {lang === 'zh'
              ? '管理跨区域研发团队配置、任务承接负荷与即时协同联络'
              : 'Manage team assignments, capacity distribution, and direct communication channels.'}
          </p>
        </div>

        <button
          onClick={() => setIsInviteOpen(true)}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-2xl bg-primary text-on-primary font-semibold text-sm shadow-sm hover:opacity-90 active:scale-95 transition-all self-start sm:self-auto cursor-pointer"
        >
          <span className="material-symbols-outlined text-lg">person_add</span>
          {lang === 'zh' ? '邀请成员加入 (Invite)' : 'Invite Member'}
        </button>
      </div>

      {/* Invite Member Modal/Box if open */}
      {isInviteOpen && (
        <div className="bg-primary-container/20 p-6 rounded-3xl border border-primary/30 animate-in">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg text-on-surface flex items-center gap-2">
              <span className="material-symbols-outlined text-primary">mail</span>
              {lang === 'zh' ? '发送协作空间邀请通知' : 'Send Workspace Invitation'}
            </h3>
            <button
              onClick={() => setIsInviteOpen(false)}
              className="text-on-surface-variant hover:text-on-surface p-1"
            >
              <span className="material-symbols-outlined">close</span>
            </button>
          </div>
          <form onSubmit={handleInvite} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input
              type="email"
              placeholder={lang === 'zh' ? '输入同事邮箱 (例如: david@flow.io)' : 'Email address...'}
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
              required
              className="px-4 py-2 rounded-xl bg-surface border border-outline-variant focus:outline-none focus:ring-2 focus:ring-primary text-sm"
            />
            <select
              value={inviteRole}
              onChange={(e) => setInviteRole(e.target.value)}
              className="px-4 py-2 rounded-xl bg-surface border border-outline-variant focus:outline-none focus:ring-2 focus:ring-primary text-sm"
            >
              <option value="Senior Engineer">Senior Engineer ({lang === 'zh' ? '资深工程师' : 'Dev'})</option>
              <option value="Product Manager">Product Manager ({lang === 'zh' ? '产品专家' : 'PM'})</option>
              <option value="UI/UX Designer">UI/UX Designer ({lang === 'zh' ? '体验设计师' : 'Design'})</option>
              <option value="DevOps Lead">DevOps Lead ({lang === 'zh' ? '运维架构师' : 'DevOps'})</option>
            </select>
            <button
              type="submit"
              className="px-6 py-2 rounded-xl bg-primary text-on-primary font-bold text-sm shadow-xs hover:opacity-90 transition-all cursor-pointer"
            >
              {lang === 'zh' ? '立即发送邀请邀请信' : 'Send Invite'}
            </button>
          </form>
        </div>
      )}

      {/* Filter Bar */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-center bg-surface-container-lowest p-4 rounded-2xl border border-outline-variant/30">
        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-2 sm:pb-0">
          {departments.map((dept) => (
            <button
              key={dept.id}
              onClick={() => setSelectedDept(dept.id)}
              className={`px-4 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedDept === dept.id
                  ? 'bg-secondary-container text-on-secondary-container font-bold shadow-xs'
                  : 'text-on-surface-variant hover:bg-surface-container-high'
              }`}
            >
              {lang === 'zh' ? dept.labelZh : dept.labelEn}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <span className="material-symbols-outlined absolute left-3 top-2.5 text-outline text-lg">
            search
          </span>
          <input
            type="text"
            placeholder={lang === 'zh' ? '搜索成员姓名、职位或部门...' : 'Search members...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-surface-container border border-outline-variant/50 focus:outline-none focus:ring-2 focus:ring-primary/40 text-on-surface placeholder:text-on-surface-variant"
          />
        </div>
      </div>

      {/* Members Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMembers.map((member) => (
          <div
            key={member.id}
            className="bg-surface-container-lowest rounded-3xl p-6 border border-outline-variant/30 shadow-xs hover:shadow-md transition-all flex flex-col justify-between group hover:border-primary/40"
          >
            <div>
              <div className="flex items-start justify-between gap-4">
                <div className="relative">
                  <img
                    src={member.avatar}
                    alt={member.name}
                    className="w-16 h-16 rounded-2xl object-cover ring-2 ring-outline-variant/30 group-hover:ring-primary/50 transition-all"
                  />
                  <div className="absolute -bottom-1 -right-1">
                    {member.status === 'online' ? (
                      <span className="w-4 h-4 rounded-full bg-emerald-500 border-2 border-surface block" />
                    ) : member.status === 'busy' ? (
                      <span className="w-4 h-4 rounded-full bg-amber-500 border-2 border-surface block" />
                    ) : (
                      <span className="w-4 h-4 rounded-full bg-slate-400 border-2 border-surface block" />
                    )}
                  </div>
                </div>

                <div className="flex flex-col items-end gap-2">
                  {statusBadge(member.status)}
                  <span className="text-xs text-on-surface-variant bg-surface-container px-2.5 py-1 rounded-lg font-mono">
                    {member.tasksCount || 0} {lang === 'zh' ? '个待办项' : 'tasks'}
                  </span>
                </div>
              </div>

              <div className="mt-4">
                <h3 className="text-lg font-bold text-on-surface group-hover:text-primary transition-colors">
                  {member.name}
                </h3>
                <p className="text-xs font-semibold text-primary mt-0.5">{member.role}</p>
                <p className="text-xs text-on-surface-variant mt-2 flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-sm">apartment</span>
                  {member.department || 'Engineering'}
                </p>
                <p className="text-xs text-on-surface-variant mt-1 flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-sm">mail</span>
                  {member.email || `${member.name.toLowerCase().replace(' ', '.')}@flow.io`}
                </p>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-6 pt-4 border-t border-outline-variant/20 flex items-center gap-2">
              <button
                onClick={onNavigateToMessages}
                className="flex-1 py-2 px-3 rounded-xl bg-surface-container-high hover:bg-primary hover:text-on-primary text-on-surface text-xs font-semibold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span className="material-symbols-outlined text-sm">chat</span>
                {lang === 'zh' ? '发起沟通 (Chat)' : 'Send Message'}
              </button>
              <button
                onClick={() => alert(lang === 'zh' ? `已向 ${member.name} 分配新看板任务` : `Task assigned to ${member.name}`)}
                className="py-2 px-3 rounded-xl bg-primary-container/40 hover:bg-primary hover:text-on-primary text-on-primary-container text-xs font-semibold transition-all flex items-center justify-center gap-1 cursor-pointer"
                title={lang === 'zh' ? '直接分派任务' : 'Assign Task'}
              >
                <span className="material-symbols-outlined text-sm">add_task</span>
                {lang === 'zh' ? '分派' : 'Assign'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
