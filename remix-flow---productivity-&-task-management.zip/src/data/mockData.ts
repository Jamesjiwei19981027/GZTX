import { Task, Project, TeamMember, Activity, UserProfile, AppSettings, MessageItem, IntegrationItem, NotificationItem, PeopleAxisNode } from '../types';

export const INITIAL_USER: UserProfile = {
  name: 'Alexander Morgan',
  email: 'alexander.morgan@flow.io',
  role: 'Product Lead',
  avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC3nDcUsokoM2sMzThEG22DP6J_RJ73jK988_axPKwS-7U7tS91_PLlI171m6EEcVUOxEu8wHZEBohHiJv_oGKBjW5t4yV-XRil7IJC2d5aZtqkJWuvJAjehPcHHe6eSLDt2qfYyAjT92Vwxrpr9rDFp1P76RNLwD_DbYuIzhAEO31comGxnmRAlB7BC5IIyHviDeZvejdTCDe8_MKsuJPMbdwnVyJX1NdjqtR80dVQQMXsOYZnufuMfZJkBM7cEHQ2rtDEpM-ryCw',
};

export const TEAM_MEMBERS: TeamMember[] = [
  {
    id: 'm1',
    name: 'Elena Rostova',
    role: 'System Architect',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCLIUef_T9yyt5DBZHSqkERF3xdyYTgmkExsjowwmOPCEYRQlpWXzi78lcrcvTjbCU0QHp9lO4YVQcfKbl1nn4SKK68GiSOlMYQkcarpOgCvBwyaUAqqrdLXkitXC1wgo8wcIv5rZWU11JOarZIn8npNBEFpFmiGTWIuxY4jZfpSgClOr0g6yvoOvbwqjGD7ME2KOXL9LZ2D7V4oZ54-J99gXFCbP0zjI0wntd5jHUEn9ssLKf-hp_U4_Xfcc_te4u7uA1WYTxVFug',
    status: 'online',
    department: 'Engineering (基础架构组)',
    email: 'elena.r@flow.io',
    tasksCount: 8,
  },
  {
    id: 'm2',
    name: 'Chloe Bennett',
    role: 'UI/UX Designer',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA6xUg38Bf5BfMhUHZPfmAOikKCidTMV0sFGCVzXQzE9uEMfSNfBsokfBhPPhuA1Orsws23P3FqYvtTsDa06CAd0qTQ1ImFlKLRi_xnMGoX-Rxs64EW1xOhgsJeQgyGXrl584YJWpOne8fgulifT1ZR6B_alkVHVgjsrefR4uKtBXVYGtbI92m0paDIo5e7cHAt_pp3a575GnHgc6X-wJ1zr4fb8hTtRkRpbYFxUP4011Ly2LyzafO-DyRCJX1zOGLGBoMIhsjHrkA',
    status: 'online',
    department: 'Design (设计体验部)',
    email: 'chloe.b@flow.io',
    tasksCount: 5,
  },
  {
    id: 'm3',
    name: 'Marcus Vance',
    role: 'Backend Lead',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAj7BeNVHAPDCzodV-hnMYnreA5v2QyWJWK8HfVeLU4LpnW4H8Bi2zwpsBGjA8A7JD-pGOfOiIRxzUw91PHq5tDvZIn6dTLI-8FNOUPpqRhWIBvAlXMbZLmzJ8tJ12VakEjcb9py-7uhd83SrU_UzZ8iPCLzdaYmWw4tdhS2NSeGc1U8zYhI1feXICNwa4w-KkCSZmDaFEPOqUaTxlD7sA3BDwIRtisBNqmL4r_Oj77LRl9_E7JIjqyzVi4I_qSjOyL1hNiomN-2Oc',
    status: 'busy',
    department: 'Engineering (研发组)',
    email: 'marcus.v@flow.io',
    tasksCount: 12,
  },
  {
    id: 'm4',
    name: 'Sarah Jenkins',
    role: 'Product Manager',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBjj77R__joZCoKvjej-pm2-7iWSSx8X86_cxkxe2xzk5wKfudJOJo6TMeGl-g0uKygStJh-Z4qV37afIG8KHnpoK6If4ofdQsyxLNA3SZH9GML_6VbhNPgn4SUwswc5z5PxU1F-ORr95VHvAhHhIYCilXgM487wLjVE9sLoG-ziDTs6g0pEfZeRAXGIa1kDpgk0DzXUsyLsDUotEBgQBh2kk3b0OWJkk1NnQBNS7JriycsN9BP4Mwi5oq7drmyhg4cH-6wL_IQJP4',
    status: 'online',
    department: 'Product (产品研发部)',
    email: 'sarah.j@flow.io',
    tasksCount: 6,
  },
  {
    id: 'm5',
    name: 'Sophia Chen',
    role: 'Frontend Engineer',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBFrx6aHoQ5QATRNanTAAnXlYt7DTovpcvtIMBkU1khQ2rcp0B9yRcj8NrzbgeIQ6BKJqyVPfB7sZJcjfy-uTRUnrX-bRERiKQ1UBKj1CXpvDxCWYsFV9wJZCDaL9C36r5XgbIYvPmpMgBmJ7Zx-xywWPXanpkZ14oN2No5X5Bje43cHLrh1QLTcprBkvm0fsrWi5o8wgnP_3tKe--Hc1EnJYRAFYolGQ3Qj7ZBVXmZWX3wwxZH1PsbA7ub2UIm41NWUIvzqwu9CxM',
    status: 'offline',
    department: 'Engineering (前端体验部)',
    email: 'sophia.c@flow.io',
    tasksCount: 4,
  },
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'p1',
    name: '企业云平台升级 (Cloud Platform Upgrade)',
    description: '重构微服务与权限控制层，全面提升企业云效体验',
    color: '#0058be',
    active: true,
  },
  {
    id: 'p2',
    name: '移动端体验重构 (Mobile App Redesign)',
    description: '全新设计语言与性能优化，打造极致触控流程',
    color: '#006c49',
    active: false,
  },
  {
    id: 'p3',
    name: 'Q4 战略产品规划 (Q4 Roadmap Alignment)',
    description: '战略产品路线图制定与跨部门协同审查',
    color: '#924700',
    active: false,
  },
  {
    id: 'p4',
    name: '安全认证体系规范 (Auth System Audit)',
    description: '对接 OAuth 2.0 与零信任安全鉴权机制',
    color: '#ba1a1a',
    active: false,
  },
];

export const INITIAL_TASKS: Task[] = [
  {
    id: 't1',
    title: '设计新版用户权限模型文档 (Design New User Permission Model)',
    description: '针对复杂架构设计细粒度 RBAC 权限控制矩阵文档，规范各业务模块接口鉴权流程。需要与技术和业务团队进行两轮沟通确认。',
    priority: 'High',
    status: 'To Do',
    category: 'Work',
    dueDate: '2024-10-24',
    dueTime: '17:00',
    assignee: TEAM_MEMBERS[0], // Elena
    tag: '技术调研',
    projectId: 'p1',
    subtasks: [
      { id: 'st1', title: '梳理现有角色权限痛点', completed: true },
      { id: 'st2', title: '草拟 RBAC 角色继承与控制矩阵', completed: false },
      { id: 'st3', title: '发起安全团队架构评审会议', completed: false },
    ],
  },
  {
    id: 't2',
    title: '完成移动端详情页高保真原型 (Mobile Detail Page Prototype)',
    description: '根据最新设计系统规范，完成移动端任务详情和评论区的交互高保真视觉稿，包括手势拖拽效果。',
    priority: 'Medium',
    status: 'To Do',
    category: 'Work',
    dueDate: '2024-10-25',
    dueTime: '18:00',
    assignee: TEAM_MEMBERS[1], // Chloe
    tag: 'UI设计',
    projectId: 'p2',
    subtasks: [
      { id: 'st4', title: '建立交互组件变体库', completed: false },
      { id: 'st5', title: '绘制关键交互跳转状态表', completed: false },
    ],
  },
  {
    id: 't3',
    title: '重构API认证层并对接OAuth2.0 (Refactor API Auth & OAuth 2.0)',
    description: '全面升级服务端安全鉴权中间件，实现 OAuth 2.0 与 JWT 双重校验体系，解决旧版 Token 过期掉线痛点。',
    priority: 'Urgent',
    status: 'In Progress',
    category: 'Work',
    dueDate: '2024-10-22',
    dueTime: '14:00',
    assignee: TEAM_MEMBERS[2], // Marcus
    tag: '后端开发',
    progress: 68,
    projectId: 'p1',
    subtasks: [
      { id: 'st6', title: '解耦旧版登录拦截器逻辑', completed: true },
      { id: 'st7', title: '集成 OAuth 2.0 授权服务器回调', completed: true },
      { id: 'st8', title: '进行高并发安全压测', completed: false },
    ],
  },
  {
    id: 't4',
    title: '第二季度项目回顾报告 (Q2 Project Retrospective Report)',
    description: '总结各项核心 KPI 达成数据与团队协同经验，制定下一季度专项改善计划。',
    priority: 'Medium',
    status: 'Done',
    category: 'Documentation',
    dueDate: '2024-10-14',
    completedAt: '昨日 (Yesterday)',
    assignee: TEAM_MEMBERS[3], // Sarah
    tag: '文档',
    projectId: 'p3',
    subtasks: [
      { id: 'st9', title: '收集各子团队交付度量数据', completed: true },
      { id: 'st10', title: '撰写回顾总结 PPT 幻灯片', completed: true },
    ],
  },
  {
    id: 't5',
    title: 'Finalize Q3 Product Strategy (敲定 Q3 产品战略规划)',
    description: 'Review the current growth metrics and align the Q3 roadmap with the new marketing objectives. Need to ensure all stakeholders are looped into the final presentation.',
    priority: 'High',
    status: 'In Progress',
    category: 'Work',
    dueDate: '2024-10-24',
    dueTime: '09:00 AM',
    assignee: TEAM_MEMBERS[0],
    tag: '战略规划',
    progress: 45,
    projectId: 'p3',
    subtasks: [
      { id: 'st11', title: 'Draft roadmap slides (草拟路线图幻灯片)', completed: true },
      { id: 'st12', title: 'Gather data from analytics team (收集分析团队数据)', completed: false },
      { id: 'st13', title: 'Schedule review meeting (预约终审会议)', completed: false },
    ],
  },
  {
    id: 't6',
    title: 'Client Feedback Implementation (落实重点客户反馈体验)',
    description: '根据近期 VIP 客户访谈报告，针对工作台交互流程进行优化。',
    priority: 'Medium',
    status: 'To Do',
    category: 'Work',
    dueDate: '2024-10-25',
    dueTime: '15:00',
    assignee: TEAM_MEMBERS[4], // Sophia
    tag: '前端体验',
    projectId: 'p1',
    subtasks: [
      { id: 'st14', title: '修复筛选器多选联动延迟', completed: false },
      { id: 'st15', title: '优化任务卡片鼠标悬停动效', completed: false },
    ],
  },
  {
    id: 't7',
    title: 'Evening Yoga Session (傍晚放松瑜伽训练)',
    description: '保持身心平衡，舒缓全天久坐带来的肩颈压力。',
    priority: 'Low',
    status: 'Done',
    category: 'Health',
    dueDate: '2024-10-15',
    completedAt: '今日 18:30',
    tag: '健康习惯',
    projectId: 'p2',
    subtasks: [
      { id: 'st16', title: '肩颈拉伸 15 分钟', completed: true },
      { id: 'st17', title: '核心腹式呼吸训练', completed: true },
    ],
  },
  {
    id: 't8',
    title: 'Research Home Insurance Providers (调研家庭保险方案对比)',
    description: '对比 3 家主流险种的承保范围与理赔便捷度，选定年度续保推荐方案。',
    priority: 'Medium',
    status: 'To Do',
    category: 'Personal',
    dueDate: '2024-10-30',
    tag: '个人事务',
    projectId: 'p3',
    subtasks: [
      { id: 'st18', title: '索取详细理赔条款说明书', completed: false },
      { id: 'st19', title: '整理年度费用对比表格', completed: false },
    ],
  },
  {
    id: 't9',
    title: '完成品牌视觉识别系统升级 (Finish Brand Identity System)',
    description: '针对官网和移动客户端统一全新的色彩体系和图标标准库。',
    priority: 'High',
    status: 'In Progress',
    category: 'Work',
    dueDate: '2024-10-15',
    dueTime: '09:00 AM - 10:30 AM',
    assignee: TEAM_MEMBERS[1],
    tag: '品牌视觉',
    progress: 80,
    projectId: 'p2',
    subtasks: [
      { id: 'st20', title: '确立色阶与明暗对比度规范', completed: true },
      { id: 'st21', title: '生成 Lucide 图标集组件映射', completed: true },
    ],
  },
  {
    id: 't10',
    title: '团队每日站会与冲刺同步 (Team Daily Standup & Sprint Sync)',
    description: '对接昨日研发进度，排查卡点与风险，分配当前冲刺余下任务。',
    priority: 'Medium',
    status: 'To Do',
    category: 'Work',
    dueDate: '2024-10-15',
    dueTime: '11:00 AM',
    assignee: TEAM_MEMBERS[3],
    tag: '敏捷协作',
    projectId: 'p1',
    subtasks: [
      { id: 'st22', title: '核对燃尽图趋势', completed: false },
    ],
  },
  {
    id: 't11',
    title: '与 Sarah 商务午餐会谈 (Lunch with Sarah)',
    description: '商讨跨部门资源协调及新季度核心开发计划对接。',
    priority: 'Medium',
    status: 'To Do',
    category: 'Personal',
    dueDate: '2024-10-15',
    dueTime: '01:00 PM',
    assignee: TEAM_MEMBERS[3],
    tag: '社交会谈',
    projectId: 'p3',
    subtasks: [],
  },
  {
    id: 't12',
    title: '审查核心模块 PR #452 (Review PR #452)',
    description: '检查新代码对内存占用和并发锁性能的影响，确保安全上线。',
    priority: 'High',
    status: 'To Do',
    category: 'Work',
    dueDate: '2024-10-15',
    dueTime: '03:30 PM',
    assignee: TEAM_MEMBERS[2],
    tag: '代码审查',
    projectId: 'p1',
    subtasks: [
      { id: 'st23', title: '验证单元测试覆盖率', completed: false },
    ],
  },
];

export const INITIAL_ACTIVITIES: Activity[] = [
  {
    id: 'act1',
    type: 'completed',
    titleText: '任务已完成 (Task completed):',
    targetText: '移动端应用线框图 (Mobile App Wireframes)',
    timestamp: '20 分钟前 (20 mins ago)',
    icon: 'check',
    colorClass: 'bg-secondary-container text-on-secondary-container',
  },
  {
    id: 'act2',
    type: 'updated',
    titleText: '任务已更新 (Task updated):',
    targetText: '客户演示幻灯片 (Client Presentation Slides)',
    timestamp: '2 小时前 (2 hours ago)',
    icon: 'edit',
    colorClass: 'bg-primary-fixed text-on-primary-fixed',
  },
  {
    id: 'act3',
    type: 'collaborator',
    titleText: '新协作者 (New collaborator):',
    targetText: 'Sarah 加入了 "网页刷新 (Web Refresh)" 项目',
    timestamp: '5 小时前 (5 hours ago)',
    icon: 'group',
    colorClass: 'bg-tertiary-fixed text-on-tertiary-fixed',
  },
];

export const INITIAL_SETTINGS: AppSettings = {
  themeMode: 'light',
  accentColor: 'blue',
  language: 'zh', // Default to Chinese as requested in prompt, with switch to English
  notifications: {
    email: true,
    push: true,
    desktop: false,
  },
  taskDefaults: {
    priority: 'Medium',
    category: 'Work',
  },
};

// Local storage keys
const TASKS_KEY = 'flow_app_tasks_v1';
const PROJECTS_KEY = 'flow_app_projects_v1';
const SETTINGS_KEY = 'flow_app_settings_v1';

export function loadTasks(): Task[] {
  try {
    const data = localStorage.getItem(TASKS_KEY);
    return data ? JSON.parse(data) : INITIAL_TASKS;
  } catch (e) {
    return INITIAL_TASKS;
  }
}

export function saveTasks(tasks: Task[]): void {
  try {
    localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
  } catch (e) {
    console.error('Failed to save tasks', e);
  }
}

export function loadProjects(): Project[] {
  try {
    const data = localStorage.getItem(PROJECTS_KEY);
    return data ? JSON.parse(data) : INITIAL_PROJECTS;
  } catch (e) {
    return INITIAL_PROJECTS;
  }
}

export function saveProjects(projects: Project[]): void {
  try {
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
  } catch (e) {
    console.error('Failed to save projects', e);
  }
}

export function loadSettings(): AppSettings {
  try {
    const data = localStorage.getItem(SETTINGS_KEY);
    return data ? JSON.parse(data) : INITIAL_SETTINGS;
  } catch (e) {
    return INITIAL_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings', e);
  }
}

export function resetDemoData(): void {
  try {
    localStorage.setItem(TASKS_KEY, JSON.stringify(INITIAL_TASKS));
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(INITIAL_PROJECTS));
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(INITIAL_SETTINGS));
    localStorage.setItem('flow_app_messages', JSON.stringify(INITIAL_MESSAGES));
    localStorage.setItem('flow_app_integrations', JSON.stringify(INITIAL_INTEGRATIONS));
    localStorage.setItem('flow_app_notifications', JSON.stringify(INITIAL_NOTIFICATIONS));
  } catch (e) {
    console.error('Failed to reset demo data', e);
  }
}

export const INITIAL_MESSAGES: MessageItem[] = [
  {
    id: 'msg_1',
    senderName: 'Elena Rostova',
    senderAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCLIUef_T9yyt5DBZHSqkERF3xdyYTgmkExsjowwmOPCEYRQlpWXzi78lcrcvTjbCU0QHp9lO4YVQcfKbl1nn4SKK68GiSOlMYQkcarpOgCvBwyaUAqqrdLXkitXC1wgo8wcIv5rZWU11JOarZIn8npNBEFpFmiGTWIuxY4jZfpSgClOr0g6yvoOvbwqjGD7ME2KOXL9LZ2D7V4oZ54-J99gXFCbP0zjI0wntd5jHUEn9ssLKf-hp_U4_Xfcc_te4u7uA1WYTxVFug',
    content: '新版平台重构的 API 鉴权网关已经完成单测，大家可以去 Sandbox 联调体验了！🔥',
    timestamp: '10:45 AM',
    channel: 'general',
    likes: 8,
    repliesCount: 3,
  },
  {
    id: 'msg_2',
    senderName: 'Marcus Vance',
    senderAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAj7BeNVHAPDCzodV-hnMYnreA5v2QyWJWK8HfVeLU4LpnW4H8Bi2zwpsBGjA8A7JD-pGOfOiIRxzUw91PHq5tDvZIn6dTLI-8FNOUPpqRhWIBvAlXMbZLmzJ8tJ12VakEjcb9py-7uhd83SrU_UzZ8iPCLzdaYmWw4tdhS2NSeGc1U8zYhI1feXICNwa4w-KkCSZmDaFEPOqUaTxlD7sA3BDwIRtisBNqmL4r_Oj77LRl9_E7JIjqyzVi4I_qSjOyL1hNiomN-2Oc',
    content: '正在优化高并发场景下的 Redis 缓存池读写穿透，预计今天下午 16:00 提交 PR。',
    timestamp: '11:12 AM',
    channel: 'project',
    likes: 5,
    repliesCount: 1,
  },
  {
    id: 'msg_3',
    senderName: 'Chloe Bennett',
    senderAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA6xUg38Bf5BfMhUHZPfmAOikKCidTMV0sFGCVzXQzE9uEMfSNfBsokfBhPPhuA1Orsws23P3FqYvtTsDa06CAd0qTQ1ImFlKLRi_xnMGoX-Rxs64EW1xOhgsJeQgyGXrl584YJWpOne8fgulifT1ZR6B_alkVHVgjsrefR4uKtBXVYGtbI92m0paDIo5e7cHAt_pp3a575GnHgc6X-wJ1zr4fb8hTtRkRpbYFxUP4011Ly2LyzafO-DyRCJX1zOGLGBoMIhsjHrkA',
    content: '根据上一轮用户访谈，设计团队优化了看板视图的卡片拖拽动效与高对比度支持。',
    timestamp: 'Yesterday',
    channel: 'general',
    likes: 12,
    repliesCount: 4,
  },
  {
    id: 'msg_4',
    senderName: 'Sarah Jenkins',
    senderAvatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBjj77R__joZCoKvjej-pm2-7iWSSx8X86_cxkxe2xzk5wKfudJOJo6TMeGl-g0uKygStJh-Z4qV37afIG8KHnpoK6If4ofdQsyxLNA3SZH9GML_6VbhNPgn4SUwswc5z5PxU1F-ORr95VHvAhHhIYCilXgM487wLjVE9sLoG-ziDTs6g0pEfZeRAXGIa1kDpgk0DzXUsyLsDUotEBgQBh2kk3b0OWJkk1NnQBNS7JriycsN9BP4Mwi5oq7drmyhg4cH-6wL_IQJP4',
    content: '本季度 Q3 OKR 目标跟进会议定于本周五下午 14:00，请各位 Leader 准时出席。',
    timestamp: '2 days ago',
    channel: 'general',
    likes: 6,
    repliesCount: 0,
  },
];

export function loadMessages(): MessageItem[] {
  try {
    const data = localStorage.getItem('flow_app_messages');
    return data ? JSON.parse(data) : INITIAL_MESSAGES;
  } catch (e) {
    return INITIAL_MESSAGES;
  }
}

export function saveMessages(messages: MessageItem[]): void {
  try {
    localStorage.setItem('flow_app_messages', JSON.stringify(messages));
  } catch (e) {
    console.error('Failed to save messages', e);
  }
}

export const INITIAL_INTEGRATIONS: IntegrationItem[] = [
  {
    id: 'int_1',
    name: 'Google Workspace (Mail & Calendar)',
    icon: 'mail',
    description: '无缝同步 Gmail 邮件转为工作待办任务，自动同步 Google Calendar 日历排期。',
    category: 'Communication',
    connected: true,
    lastSync: '刚刚自动同步',
  },
  {
    id: 'int_2',
    name: 'GitHub Repository',
    icon: 'code',
    description: '关联 Commit & PR 状态，自动根据代码更新状态流转看板上的关联任务。',
    category: 'Development',
    connected: true,
    lastSync: '15分钟前',
  },
  {
    id: 'int_3',
    name: 'Slack Communication',
    icon: 'chat',
    description: '在 Slack 频道实时接收团队任务指派、评论提醒与逾期警告通知。',
    category: 'Communication',
    connected: false,
  },
  {
    id: 'int_4',
    name: 'Figma Design Cloud',
    icon: 'palette',
    description: '直接将 Figma 原型图与注释嵌入任务详情，支持评论双向连通。',
    category: 'Development',
    connected: true,
    lastSync: '2小时前',
  },
  {
    id: 'int_5',
    name: 'Google Drive & Docs',
    icon: 'folder_shared',
    description: '在工作台实时查阅并编辑设计文档、产品架构蓝图与团队周报。',
    category: 'Storage',
    connected: true,
    lastSync: '昨天',
  },
  {
    id: 'int_6',
    name: 'Jira Software Migration',
    icon: 'sync_alt',
    description: '双向同步现有 Jira 缺陷追踪库，方便跨系统团队协作无缝过渡。',
    category: 'Development',
    connected: false,
  },
];

export function loadIntegrations(): IntegrationItem[] {
  try {
    const data = localStorage.getItem('flow_app_integrations');
    return data ? JSON.parse(data) : INITIAL_INTEGRATIONS;
  } catch (e) {
    return INITIAL_INTEGRATIONS;
  }
}

export function saveIntegrations(integrations: IntegrationItem[]): void {
  try {
    localStorage.setItem('flow_app_integrations', JSON.stringify(integrations));
  } catch (e) {
    console.error('Failed to save integrations', e);
  }
}

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif_1',
    title: '任务指派提醒 (Task Assignment)',
    message: 'Sarah Jenkins 在项目「企业云平台升级」中将任务指派给了你',
    timestamp: '10 分钟前',
    read: false,
    type: 'assignment',
    linkTaskId: 't1',
  }
];

export function loadNotifications(): NotificationItem[] {
  try {
    const data = localStorage.getItem('flow_app_notifications');
    return data ? JSON.parse(data) : INITIAL_NOTIFICATIONS;
  } catch (e) {
    return INITIAL_NOTIFICATIONS;
  }
}

export function saveNotifications(notifications: NotificationItem[]): void {
  try {
    localStorage.setItem('flow_app_notifications', JSON.stringify(notifications));
  } catch (e) {
    console.error('Failed to save notifications', e);
  }
}

export const INITIAL_PEOPLE_AXIS: PeopleAxisNode[] = [
  {
    id: 'node-1',
    person: {
      id: 'm1',
      name: 'Elena Rostova',
      role: 'System Architect',
      avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCLIUef_T9yyt5DBZHSqkERF3xdyYTgmkExsjowwmOPCEYRQlpWXzi78lcrcvTjbCU0QHp9lO4YVQcfKbl1nn4SKK68GiSOlMYQkcarpOgCvBwyaUAqqrdLXkitXC1wgo8wcIv5rZWU11JOarZIn8npNBEFpFmiGTWIuxY4jZfpSgClOr0g6yvoOvbwqjGD7ME2KOXL9LZ2D7V4oZ54-J99gXFCbP0zjI0wntd5jHUEn9ssLKf-hp_U4_Xfcc_te4u7uA1WYTxVFug',
      department: 'Engineering (项目总指挥)',
    },
    orderOnAxis: 1,
    roleTitle: '项目总负责人 (Overall Project Director)',
    workItems: [
      {
        id: 'wi-101',
        title: '双端统一接口规范 & 责任树模型设计',
        type: 'milestone',
        status: 'Done',
        progress: 100,
        dueDate: '2026-07-25',
        evidences: [
          {
            id: 'ev-1',
            type: 'document',
            title: 'Liability-Axis-Schema-v2.pdf (责任树接口设计说明书)',
            url: '#doc-schema',
            timestamp: '07-24 16:30',
            verifiedBy: 'Sarah Jenkins',
            status: 'verified'
          }
        ],
        aiAnalysis: '主干责任节点及双端（Web/App）语义规则一致性已验证完毕，接口契约稳定。'
      }
    ],
    aiContext: {
      riskLevel: 'low',
      summary: 'Elena 作为项目总负责人，稳坐主干起点；各部门/厂家领导分布在主干两旁。',
      lastAnalysis: '07-28 02:00 智能体巡检: 主干结构清晰，地铁站点式拓扑运行流畅。',
      suggestedActions: ['查看下属交付进度', '确认新功能上线计划']
    }
  },
  {
    id: 'node-1-child-1',
    parentId: 'node-1',
    person: {
      id: 'm1-c1',
      name: 'Kevin Wu',
      role: 'DevOps Lead',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      department: 'Engineering (基础架构组)',
    },
    orderOnAxis: 1,
    roleTitle: 'CI/CD 自动化持续部署管线',
    workItems: [
      {
        id: 'wi-110',
        title: '构建 Web 与 Android 双端容器镜像',
        type: 'task',
        status: 'In Progress',
        progress: 90,
        dueDate: '2026-07-29',
        evidences: []
      }
    ],
    aiContext: {
      riskLevel: 'low',
      summary: '自动化部署管线畅通。',
      lastAnalysis: '07-28 03:10 智能体巡检: 部署环境健康度 100%。',
      suggestedActions: []
    }
  },
  {
    id: 'node-1-child-2',
    parentId: 'node-1',
    person: {
      id: 'm1-c2',
      name: 'Lisa Wang',
      role: 'QA Lead',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
      department: 'Engineering (质量保障组)',
    },
    orderOnAxis: 1,
    roleTitle: '自动化压测沙箱与闭环验证',
    workItems: [
      {
        id: 'wi-111',
        title: '多叉树层级极限性能与拖拽并发测试',
        type: 'task',
        status: 'In Progress',
        progress: 80,
        dueDate: '2026-07-31',
        evidences: []
      }
    ],
    aiContext: {
      riskLevel: 'low',
      summary: '测试覆盖良好。',
      lastAnalysis: '07-28 01:00 智能体巡检: 无内存泄露风险。',
      suggestedActions: []
    }
  },
  {
    id: 'node-2',
    person: {
      id: 'm3',
      name: 'Marcus Vance',
      role: 'Backend Director',
      avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAj7BeNVHAPDCzodV-hnMYnreA5v2QyWJWK8HfVeLU4LpnW4H8Bi2zwpsBGjA8A7JD-pGOfOiIRxzUw91PHq5tDvZIn6dTLI-8FNOUPpqRhWIBvAlXMbZLmzJ8tJ12VakEjcb9py-7uhd83SrU_UzZ8iPCLzdaYmWw4tdhS2NSeGc1U8zYhI1feXICNwa4w-KkCSZmDaFEPOqUaTxlD7sA3BDwIRtisBNqmL4r_Oj77LRl9_E7JIjqyzVi4I_qSjOyL1hNiomN-2Oc',
      department: 'Engineering (后端/服务厂商领导)',
    },
    orderOnAxis: 2,
    roleTitle: '服务调度与实时协同厂商负责人 (Backend Leader)',
    workItems: [
      {
        id: 'wi-201',
        title: 'Web/App 双端同一套责任树网关适配',
        type: 'task',
        status: 'In Progress',
        progress: 75,
        dueDate: '2026-08-02',
        evidences: []
      }
    ],
    aiContext: {
      riskLevel: 'low',
      summary: '后端服务响应正常。',
      lastAnalysis: '07-28 01:30 智能体巡检: 接口联调顺利。',
      suggestedActions: []
    }
  },
  {
    id: 'node-2-child-1',
    parentId: 'node-2',
    person: {
      id: 'm5',
      name: 'Sophia Chen',
      role: 'Frontend Dev',
      avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBFrx6aHoQ5QATRNanTAAnXlYt7DTovpcvtIMBkU1khQ2rcp0B9yRcj8NrzbgeIQ6BKJqyVPfB7sZJcjfy-uTRUnrX-bRERiKQ1UBKj1CXpvDxCWYsFV9wJZCDaL9C36r5XgbIYvPmpMgBmJ7Zx-xywWPXanpkZ14oN2No5X5Bje43cHLrh1QLTcprBkvm0fsrWi5o8wgnP_3tKe--Hc1EnJYRAFYolGQ3Qj7ZBVXmZWX3wwxZH1PsbA7ub2UIm41NWUIvzqwu9CxM',
      department: 'Engineering (前端体验部)',
    },
    orderOnAxis: 2,
    roleTitle: '地铁站点主干与子卡片拖拽与连线交互',
    workItems: [
      {
        id: 'wi-301',
        title: '人轴卡片 Draw.io 式拖拽与贝塞尔曲线',
        type: 'scope',
        status: 'In Progress',
        progress: 95,
        dueDate: '2026-07-29',
        evidences: []
      }
    ],
    aiContext: {
      riskLevel: 'low',
      summary: '拖拽交互响应极其迅捷。',
      lastAnalysis: '07-28 02:15 智能体巡检: 帧率稳定在 60fps。',
      suggestedActions: []
    }
  },
  {
    id: 'node-3',
    person: {
      id: 'm2',
      name: 'Chloe Bennett',
      role: 'Design Director',
      avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuA6xUg38Bf5BfMhUHZPfmAOikKCidTMV0sFGCVzXQzE9uEMfSNfBsokfBhPPhuA1Orsws23P3FqYvtTsDa06CAd0qTQ1ImFlKLRi_xnMGoX-Rxs64EW1xOhgsJeQgyGXrl584YJWpOne8fgulifT1ZR6B_alkVHVgjsrefR4uKtBXVYGtbI92m0paDIo5e7cHAt_pp3a575GnHgc6X-wJ1zr4fb8hTtRkRpbYFxUP4011Ly2LyzafO-DyRCJX1zOGLGBoMIhsjHrkA',
      department: 'Design (设计/UI厂商领导)',
    },
    orderOnAxis: 3,
    roleTitle: '设计标准与视觉体验厂商负责人 (Design Leader)',
    workItems: [
      {
        id: 'wi-401',
        title: '双端规范对照表：视觉规范与交付归口',
        type: 'milestone',
        status: 'Done',
        progress: 100,
        dueDate: '2026-07-24',
        evidences: []
      }
    ],
    aiContext: {
      riskLevel: 'low',
      summary: '设计资产已入库。',
      lastAnalysis: '07-28 00:00 智能体巡检: 高对比度标准合格。',
      suggestedActions: []
    }
  },
  {
    id: 'node-3-child-1',
    parentId: 'node-3',
    person: {
      id: 'm3-c1',
      name: 'Emma Stone',
      role: 'Visual Designer',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
      department: 'Design (视觉设计组)',
    },
    orderOnAxis: 3,
    roleTitle: '地铁站点与卡片视觉与贝塞尔平滑线动效',
    workItems: [
      {
        id: 'wi-410',
        title: '输出人轴树状视图的高品质动效',
        type: 'milestone',
        status: 'Done',
        progress: 100,
        dueDate: '2026-07-26',
        evidences: []
      }
    ],
    aiContext: {
      riskLevel: 'low',
      summary: '视觉动效方案已交付。',
      lastAnalysis: '07-28 02:00 智能体巡检: 动效落地 100%。',
      suggestedActions: []
    }
  },
  {
    id: 'node-4',
    person: {
      id: 'm4',
      name: 'Sarah Jenkins',
      role: 'Product Director',
      avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBjj77R__joZCoKvjej-pm2-7iWSSx8X86_cxkxe2xzk5wKfudJOJo6TMeGl-g0uKygStJh-Z4qV37afIG8KHnpoK6If4ofdQsyxLNA3SZH9GML_6VbhNPgn4SUwswc5z5PxU1F-ORr95VHvAhHhIYCilXgM487wLjVE9sLoG-ziDTs6g0pEfZeRAXGIa1kDpgk0DzXUsyLsDUotEBgQBh2kk3b0OWJkk1NnQBNS7JriycsN9BP4Mwi5oq7drmyhg4cH-6wL_IQJP4',
      department: 'Product (产品/需求厂商领导)',
    },
    orderOnAxis: 4,
    roleTitle: '产品需求与多轴交付主管 (Product Leader)',
    workItems: [
      {
        id: 'wi-501',
        title: 'Flow 2.0 责任链系统全模块终审验收',
        type: 'milestone',
        status: 'In Progress',
        progress: 80,
        dueDate: '2026-08-05',
        evidences: []
      }
    ],
    aiContext: {
      riskLevel: 'low',
      summary: '产品需求已明确。',
      lastAnalysis: '07-28 03:00 智能体巡检: 项目健康度 98%。',
      suggestedActions: []
    }
  }
];

export function loadPeopleAxis(): PeopleAxisNode[] {
  try {
    const data = localStorage.getItem('flow_app_people_axis');
    return data ? JSON.parse(data) : INITIAL_PEOPLE_AXIS;
  } catch (e) {
    return INITIAL_PEOPLE_AXIS;
  }
}

export function savePeopleAxis(nodes: PeopleAxisNode[]): void {
  try {
    localStorage.setItem('flow_app_people_axis', JSON.stringify(nodes));
  } catch (e) {
    console.error('Failed to save people axis', e);
  }
}

